var express=require("express"); 
var bodyParser=require("body-parser"); 

var app=express();

const mongoose = require('mongoose'); 
mongoose.set('useUnifiedTopology', true);
mongoose.set('useNewUrlParser', true);
mongoose.connect('mongodb://localhost:27017/mydb'); 

var db=mongoose.connection; 
db.on('error', console.log.bind(console, "connection error")); 
db.once('open', function(callback){ 
	console.log("connection succeeded"); 
}) 



var path = require('path');

app.use(bodyParser.json()); 
app.use(express.static(__dirname + '/public')); 

app.use(bodyParser.urlencoded({ 
	extended: false
})); 

app.post('/sign_up', function(req,res){ 
	var name = req.body.name; 
	var email =req.body.email; 
	var pass = req.body.password; 
	var phone =req.body.phone; 

	var data = { 
		"name": name, 
		"email":email, 
		"password":pass, 
		"phone":phone 
	} 
db.collection('details').insertOne(data,function(err, collection){ 
		if (err) throw err; 
		console.log("Record inserted Successfully"); 
			
	}); 
		
	return res.redirect('signup_success.html'); 
}) 



app.get('/',function(req,res){ 
res.set({ 
	'Access-control-Allow-Origin': '*'
	});

	return res.redirect('index.html');

}).listen(3000);


console.log("server listening at port 3000"); 
